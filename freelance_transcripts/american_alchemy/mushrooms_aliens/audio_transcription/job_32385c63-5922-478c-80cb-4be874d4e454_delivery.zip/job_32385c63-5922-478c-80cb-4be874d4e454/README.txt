================================================================================
TRANSCRIPTION DELIVERY PACKAGE
================================================================================

Job ID: 32385c63-5922-478c-80cb-4be874d4e454
Client: TEST - Full Sliding Window - Mushrooms
Service Tier: PREMIUM
Created: 2026-01-15 11:11:46

PACKAGE CONTENTS
--------------------------------------------------------------------------------

📄 Transcripts (transcripts/)
   - transcript.txt: Plain text transcript
   - transcript.json: JSON with timestamps and metadata

📝 Subtitles (subtitles/)
   - subtitles.srt: SRT format (compatible with most players)
   - subtitles.vtt: WebVTT format (HTML5 video)

USAGE INSTRUCTIONS
--------------------------------------------------------------------------------

Plain Text Transcript:
  Open transcript.txt with any text editor for the full text.

Subtitle Files:
  - Import .srt or .vtt into video editors (Premiere, Final Cut, etc.)
  - Use with media players (VLC, MPV) for overlay subtitles
  - Upload to YouTube/Vimeo for closed captions

QUALITY METRICS
--------------------------------------------------------------------------------

Overall Quality Score: 0.96/1.00
Average Confidence: 0.90
Processing Speed: 7.4x real-time

See transcript_quality_report.txt for detailed metrics.

SUPPORT
--------------------------------------------------------------------------------

If you have any questions or need revisions, please contact us
with your Job ID.

================================================================================
Thank you for using our transcription service!
================================================================================