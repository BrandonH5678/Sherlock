================================================================================
TRANSCRIPTION DELIVERY PACKAGE
================================================================================

Job ID: 87bc1479-c80d-49cd-b976-8d470439bcf0
Client: TEST - FINAL Sliding Window - Mushrooms
Service Tier: PREMIUM
Created: 2026-01-16 12:53:22

PACKAGE CONTENTS
--------------------------------------------------------------------------------

📄 Transcripts (transcripts/)
   - transcript.txt: Plain text transcript
   - transcript.json: JSON with timestamps and metadata

📝 Subtitles (subtitles/)
   - subtitles.srt: SRT format (compatible with most players)
   - subtitles.vtt: WebVTT format (HTML5 video)

USAGE INSTRUCTIONS
--------------------------------------------------------------------------------

Plain Text Transcript:
  Open transcript.txt with any text editor for the full text.

Subtitle Files:
  - Import .srt or .vtt into video editors (Premiere, Final Cut, etc.)
  - Use with media players (VLC, MPV) for overlay subtitles
  - Upload to YouTube/Vimeo for closed captions

QUALITY METRICS
--------------------------------------------------------------------------------

Overall Quality Score: 0.96/1.00
Average Confidence: 0.91
Processing Speed: 10.3x real-time

See transcript_quality_report.txt for detailed metrics.

SUPPORT
--------------------------------------------------------------------------------

If you have any questions or need revisions, please contact us
with your Job ID.

================================================================================
Thank you for using our transcription service!
================================================================================